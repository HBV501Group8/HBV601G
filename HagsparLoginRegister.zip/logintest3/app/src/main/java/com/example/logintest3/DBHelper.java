package com.example.logintest3;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

import Model.Users;

public class DBHelper extends SQLiteOpenHelper {
    public static final String DBNAME = "Forecasttest.db";
    public DBHelper(Context context) {
        super(context, "Forecasttest.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase MyDB) {
        MyDB.execSQL("create Table users(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT , password TEXT,EmailUser TEXT,Namereal TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase MyDB, int i, int i1) {
        MyDB.execSQL("drop Table if exists users");
    }

    public Boolean insertData(String username, String password,String mail, String realname){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues= new ContentValues();
        contentValues.put("username", username);
        contentValues.put("password", password);
        contentValues.put("EmailUser", mail);
        contentValues.put("Namereal", realname);
        long result = MyDB.insert("users", null, contentValues);
        if(result==-1) return false;
        else
            return true;
    }

    public Boolean checkusername(String username) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from users where username = ?", new String[]{username});
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
    }
    public List<String> getUser(String username) {
        List<String> returnList = new ArrayList<>();
        String userName="";

        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from users where username = ?", new String[]{username});
///        if (cursor.getCount() > 0)
        if(cursor.moveToFirst()) {
            int userID= cursor.getInt(0);
            userName = cursor.getString(3);
            String userPassword = cursor.getString(4);
           String Mail = cursor.getString(2);
           String realName = cursor.getString(1);
           String ID= userID+"";
//        returnUser.add(ID + "");
//        returnUser.add(userPassword);
            //       returnUser.add(Mail);
            //       returnUser.add(realName);
            returnList.add(ID);
            returnList.add(realName);
            returnList.add(Mail);
            returnList.add(username);
            returnList.add(userPassword);
        }
        return returnList;

    }

    public Boolean checkusernamepassword(String username, String password){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from users where username = ? and password = ?", new String[] {username,password});
        if(cursor.getCount()>0)
            return true;
        else
            return false;
    }
    public List<String> getAll() {

        List<String> returnList = new ArrayList<>();
        String queryString = "Select * from Users";
        SQLiteDatabase MyDB = this.getReadableDatabase();
        Cursor cursor = MyDB.rawQuery(queryString,null);
        if(cursor.moveToFirst()) {
            do {

                int userID= cursor.getInt(0);
                String userName = cursor.getString(1);
                String userPassword = cursor.getString(2);
                String Mail = cursor.getString(3);
                String realName = cursor.getString(4);
//                Users user = new Users(userName, userPassword,Mail,realName);

                returnList.add(userID  + "" + " " + userName);







            } while (cursor.moveToNext());
        } else {
            // failure
        }
        cursor.close();
        MyDB.close();

        return returnList;

    }
    public List<Users>  geteveryone() {
        List<Users> returnList = new ArrayList<>();
        SQLiteDatabase MyDB = this.getWritableDatabase();
        String mQuery = "SELECT username,password From users";
        Cursor mCur = MyDB.rawQuery(mQuery, new String[]{});
        mCur.moveToFirst();
        String name="",password="",mail="",realName="";

        while ( !mCur.isAfterLast()) {
            int userID= mCur.getInt(0);
            name= mCur.getString(mCur.getColumnIndex("username"));
            password= mCur.getString(mCur.getColumnIndex("password"));
            mail= mCur.getString(mCur.getColumnIndex("Email"));
            realName = mCur.getString(mCur.getColumnIndex("Email"));
            mCur.moveToNext();
            Users user =new Users(name,password,mail,realName);
            returnList.add(user);
        }
        return returnList   ;
    }
    public void getusername(String username) {
      //  SQLiteDatabase MyDB = this.getWritableDatabase();
    //    Cursor cursor = MyDB.rawQuery("Select * from users where username = ?", new String[]{"Sigurjon"});
    }
    public void resetDB() {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        MyDB.execSQL("drop Table if exists users");
        MyDB.execSQL("create Table users(id INTEGER PRIMARY KEY,username TEXT , password TEXT)");
    }
}