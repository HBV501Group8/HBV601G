package com.example.logintest3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import Model.Users;

public class adminActivity extends AppCompatActivity {
    Button btnViewAll;
    ListView llAll;
    DBHelper DB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        //btnViewAll = (Button) findViewById(R.id.btn_V);
        llAll = (ListView) findViewById(R.id.ll_ViewAll);
        DB = new DBHelper(this);

              List<String> returnList = new ArrayList<>();
              returnList = DB.getAll();



        ArrayAdapter userArrayAdapter = new ArrayAdapter<String>(adminActivity.this,  android.R.layout.simple_list_item_checked,returnList);
                llAll.setAdapter(userArrayAdapter);

                 llAll.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                     @Override
                     public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                         Intent intent  = new Intent(getApplicationContext(), UserDetailActivity.class);
                         String value="sigjol";
                         intent.putExtra("username", value);
                         startActivity(intent);
                     }
                 });

                //Toast.makeText(adminActivity.this,returnList.toString(), Toast.LENGTH_SHORT).show();
            }


    }

