package com.example.logintest3;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {


    EditText username, password, repassword,realname,email;
    Button signup, signin, btnreset,btnAdmin,btnHome,btnCreateUser;
    DBHelper DB,DB2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //btnreset = (Button) findViewById(R.id.btnreset);
        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
        realname = (EditText) findViewById(R.id.userRealname);
        email = (EditText) findViewById(R.id.emailuser);

        repassword = (EditText) findViewById(R.id.repassword);
        signup = (Button) findViewById(R.id.btnsignup);
        signin = (Button) findViewById(R.id.btnsignin);
        btnAdmin = (Button) findViewById(R.id.btnadmin);
        btnHome = (Button) findViewById(R.id.btnhome);
        btnCreateUser = (Button)  findViewById(R.id.btnInsertUser);

        List<String> returnList = new ArrayList<>();

        DB = new DBHelper(this);



    //    }
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = username.getText().toString();
                String pass = password.getText().toString();
                String repass = repassword.getText().toString();
                String mail = email.getText().toString();
                String realName = realname.getText().toString();

                if(user.equals("")||pass.equals("")||repass.equals(""))
                    Toast.makeText(MainActivity.this, R.string.Enter_All_Fields, Toast.LENGTH_SHORT).show();
                else{
                    if(pass.equals(repass)){
                        Boolean checkuser = DB.checkusername(user);
                        if(checkuser==false){
                            Boolean insert = DB.insertData(user, pass,mail,realName);
                            if(insert==true){
                                Toast.makeText(MainActivity.this, R.string.Register_Success, Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getApplicationContext(),adminActivity.class);
                                startActivity(intent);
                            }else{
                                Toast.makeText(MainActivity.this, R.string.Registration_Failed, Toast.LENGTH_SHORT).show();
                            }
                        }
                        else{
                            Toast.makeText(MainActivity.this, R.string.User_Exssits, Toast.LENGTH_SHORT).show();
                        }
                    }else{
                        Toast.makeText(MainActivity.this, R.string.Password_NotMatch, Toast.LENGTH_SHORT).show();
                    }
                } }
        });

        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
            }
        });


        btnAdmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(), adminActivity.class);
                startActivity(intent);

            }
        });
        btnHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(), HomeActivity.class);

                startActivity(intent);

            }
        });
        btnCreateUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = "admin";
                String pass = "admin";
                String mail = "sigurjon@text.is";
                String realName = "Sigurjón Ólafsson";

                Boolean insert = DB.insertData(user, pass,mail,realName);

            }
        });
    }


}
