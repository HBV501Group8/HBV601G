package com.example.logintest3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;

public class ForecastInputActivity extends AppCompatActivity {
    Button btnLogout;
    DBHelper DB;
    ListView llAll;
    List<String> returnList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forecast_input);
       btnLogout = (Button) findViewById(R.id.btnLogout);
        llAll = (ListView) findViewById(R.id.ll_ViewAll);
              DB = new DBHelper(this);
        returnList.add("Fjöldi Íslenskra ríkisborgara");
        returnList.add("Fjöldi Erlendra ríkisborgara");
        returnList.add("Atvinnuleysi");
        returnList.add("Atvinnuleysi í Reykjavík");
        returnList.add("Einkaneysla");
        returnList.add("Samneysla");
        returnList.add("Fjármunamyndun");
        returnList.add("Útflutningur vara");
        returnList.add("Útflutningur þjónustu ");
        returnList.add("Innflutningur þjónustu ");
        returnList.add("Innflutningur þjónustu ");
        returnList.add("Verg landframleiðsla ");

        ArrayAdapter userArrayAdapter = new ArrayAdapter<String>(this,  R.layout.customspar,R.id.checkbox,returnList);
        llAll.setAdapter(userArrayAdapter);
        llAll.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override

            // Event handler fyrir lista af users

            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent  = new Intent(getApplicationContext(), UserDetailActivity.class);
                String Value = returnList.get(position);
                intent.putExtra(getString(R.string.User_Key_Admin), Value);
                startActivity(intent);
            }
        });

        // Event handler fyrir logout

        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent  = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }


        });
    }

}