package com.example.logintest3;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.List;

import Model.Users;

public class HomeActivity extends AppCompatActivity {
    Button btnViewAll;
    ListView llAll;
    DBHelper DB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        DB = new DBHelper(this);

        btnViewAll = (Button) findViewById(R.id.btn_Viewall);
        llAll = (ListView) findViewById(R.id.llAll);

        btnViewAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<String> everyone = DB.getAll();

           //     ArrayAdapter userArrayAdapter = new ArrayAdapter<Users>(HomeActivity.this,  android.R.layout.simple_list_item_1,everyone);
           //     llAll.setAdapter(userArrayAdapter);

            }
        });

    }

}